BLACK = '\033[30m'
RED = '\033[31m'
GREEN = '\033[32m'
YELLOW = '\033[33m'
CYAN = '\033[34m'
MAGENTA = '\033[35m'
CYAN = '\033[36m'
WHITE = '\033[37m'

enabled = True

def colorify(color, text):
    global enbled
    if enabled:
        return color + text + '\033[0m'
    else:
        return text
