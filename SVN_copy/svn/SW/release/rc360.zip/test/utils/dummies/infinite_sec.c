#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
	printf("APP: Hundred Second App Launched!\n");

	while(1);
}
