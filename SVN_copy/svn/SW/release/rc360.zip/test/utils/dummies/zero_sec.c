#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
	printf("APP: Zero Second App Launched!\n");

	// sleep(1);

	printf("APP: Zero Second App Ended!\n");
}
