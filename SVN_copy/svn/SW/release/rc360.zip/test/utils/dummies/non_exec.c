// This file can't be executed!!

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char *argv[])
{
	while(1)
	{
		printf("This should not be running!! \n");
		sleep(1);
	}
}

