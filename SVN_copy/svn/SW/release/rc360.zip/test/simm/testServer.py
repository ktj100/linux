#!/usr/bin/env python3

import socket

if __name__ == '__main__':
    #TCP
    TCP_IP = "127.0.0.1"
    TCP_PORT = 8000

    REGISTER_APP_STR = '=HHBII'
    REGISTER_APP_ACK_STR ='HHH'
    REGISTER_DATA_STR = 'HHB'+23*'I'
    REGISTER_DATA_ACK_STR = 25*'H'

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    print( 'Socket created')
    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        s.bind( (TCP_IP, TCP_PORT) )
    except msg:
        print( 'Bind failed. Error code: ' + str(msg[0]) + 'Error message: ' + msg[1])
        conn.close()
        s.close()
        sys.exit()
    print('Socket bind complete')
    s.listen(1)
    print('Socket now listening')

    # Accept the connection
    (conn, addr) = s.accept()
    print('Server: got connection from client ' + addr[0] + ':' + str(addr[1]) )

    #while 1:
    #RECEIVE REGISTER_APP
    data = conn.recvfrom(1024)
    data = data[0]
    data_bytes = data[0:13]
    from struct import unpack
    print(unpack(REGISTER_APP_STR , data_bytes))
    #conn.send(reply)
    conn.close()
    s.close()
